/**
 * Package containing the main project classes.
 */
package net.ypetit;

