/**
 * Package containing a mock implementation of fuse4j-hadoopfs HdfsClient
 * interface.
 */
package net.ypetit.fuse4j.hadoopfs;

